// ============================================================================
// diceplot.cpp
//
//
// ============================================================================

#include <iostream>
#include <cstdlib>
using namespace std;

// Prototype/define functions anywhere below
void printHistogram(int counts[]) {
  int i;
  int j;
  int k = 0;


  for (i = 4; i < 25; ++i, ++k) {
    cout << i << ":";
    for (j = 1; j <= counts[k]; ++j) {
      cout << "X";
    }
    cout << endl;
  }

}

int roll() {
  return (rand() % 6 + 1);
}

int main()
{
  int seed, n;
  cin >> seed >> n;

  // Seed the pseudo-random number generator for repeatable results
  srand(seed);

  // Your code here
  int array[n];
  int i;
  int j;


  for (i = 0; i < n; ++i) {
    array[i] = 0;
  }

  for (i = 1; i <= n; ++i) {
    int sum = 0;
    for (j = 1; j <= 4; ++j) {
      sum += roll();
    }

    for (j = 0; j < n; ++j) {
      if (sum == (4 + j)) {
        array[j] += 1;
      }
    }
  }

  printHistogram(array);
  
  return 0;
}