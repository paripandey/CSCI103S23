#include <iostream>
using namespace std;

int main() {
  int integer = 0;
  int quotient;
  int i;
  int numTwos = 0;
  int numThrees = 0;
  bool isDivisible = true;

  while (integer < 2) {
    cout << "Enter a positive integer: ";
    cin >> integer;
    quotient = integer;
  }
  
  for (i = 2; i < integer && isDivisible; ++i) {
    if ((i % 2 != 0) && (i % 3 != 0) && (integer % i == 0)) {          isDivisible = false;
         isDivisible = false;
    }
  }

  if (isDivisible) {
    while (quotient % 2 == 0) {
      quotient /= 2;
      ++numTwos;
    }

    while (quotient % 3 == 0) {
      quotient /= 3;
      ++numThrees;
    }
        
    cout << "Yes" << endl;
    cout << "Twos=" << numTwos << " Threes=" << numThrees << endl;
  }

  else {
    cout << "No" << endl;
  }

  return 0;

}