#include "strmsrv.h"
#include <iostream>
#include <fstream>
using namespace std;

// To do - Complete this function
StreamService::StreamService()
{
  // Update as needed
  cUser_ = NULL;
}

// To do - Complete this function
StreamService::~StreamService()
{
  int i = content_.size() - 1;

  // Deallocates the contents vector
  while (i >= 0) {
    delete content_[i];
    --i;
  }

  i = users_.size() - 1;

  // Deallocates the users vector
  while (i >= 0) {
    delete users_[i];
    --i;
  }
}

// Complete - Do not alter
void StreamService::readAndParseData(std::istream& is, Parser& p)
{
  p.parse(is, content_, users_);
  cout << "Read " << content_.size() << " content items." << endl;
  cout << "Read " << users_.size() << " users." << endl;
}

// To do - Complete this function
void StreamService::userLogin(const std::string& uname)
{
  // If another user is logged in
  if (cUser_ != NULL) {
    throw std::runtime_error("Another user is logged in");
  }

  // If the username is invalid
  else if (getUserIndexByName(uname) == -1) {
    throw std::invalid_argument("Invalid username");
  }

  // Tracks the user named uname
  else {
    cUser_ = users_[getUserIndexByName(uname)];
  }
}

// To do - Complete this function
void StreamService::userLogout()
{
  if (cUser_ != NULL) {
    cUser_ = NULL;
  }
}

// To do - Complete this function
std::vector<CID_T> StreamService::searchContent(const std::string& partial) const
{
  std::vector<CID_T> results;
  for(size_t i = 0; i < content_.size(); i++){
    // TO DO - modify this to also push back when the string 'partial'
    //  is contained in the name of the current content. Lookup the string
    //  class documentation to find an appropriate function that can be used
    //  to do this simply.
    if(partial == "*" || content_[i]->name().find(partial) != string::npos){
      results.push_back(i);
    }        
  }
  return results;
}

// Complete - Do not alter
std::vector<CID_T> StreamService::getUserHistory() const
{
  // A user must be logged in
  throwIfNoCurrentUser();
  return cUser_->history;
}

// To do - Complete this function
void StreamService::watch(CID_T contentID)
{
  // A user must be logged in
  throwIfNoCurrentUser();
  // The content ID must be valid
  if (!isValidContentID(contentID)) {
    throw std::range_error("Watch: invalid contentID");
  }

  // The content ID must be under/equal to the user's rating limit
  else if (content_[contentID]->rating() > cUser_->ratingLimit) {
    throw RatingLimitError("Cannot watch this content");
  }

  // If the user hasn't already watched the content
  else if (!cUser_->haveWatched(contentID)) {
    // Add the content to the user's history / add the user as a viewer
    cUser_->addToHistory(contentID);
    content_[contentID]->addViewer(cUser_->uname); 
  }
}

// To do - Complete this function
void StreamService::reviewShow(CID_T contentID, int numStars)
{
  // A user must be logged in
  throwIfNoCurrentUser();
  
  // If the content ID isn't valid, or the number of stars is out of bounds
  if (!isValidContentID(contentID) || numStars < 0 || numStars > 5) {
    throw ReviewRangeError("Invalid review");
  }

  // Add the review to the content 
  (content_[contentID])->review(numStars);
}

// To do - Complete this function
CID_T StreamService::suggestBestSimilarContent(CID_T contentID) const
{
  // A user must be logged in
  throwIfNoCurrentUser();
  // The content ID must be valid
  if (!isValidContentID(contentID))
  {
    throw std::range_error("Invalid ID");
  }

  // Stores the other users that have viewed the content
  vector<User*> other_users;
  size_t i;

  for (i = 0; i < users_.size(); ++i) {
    // If the other users have also viewed the content
    if (users_[i] != cUser_ && users_[i]->haveWatched(contentID)) {
      other_users.push_back(users_[i]);
    }
  }

  // Will store the max views from the other users
  int max_views = 0;
  // Will store the suggested content ID
  CID_T suggested = -1;

  for (i = 0; i < content_.size(); ++i) {
    // If the suggested content is itself, and/or the user has already watched it
    if (i == size_t(contentID) || cUser_->haveWatched(i)) {
      continue; // Move to the next content
    }

    int views = 0;

    for (size_t j = 0; j < other_users.size(); ++j) {
      // Checks if every other appropriate user has watched the content
      if (other_users[j]->haveWatched(i)) {
        views++;
      }
    }
    
    // Checks if this content has more user views than the previous one
    if (views > max_views) {
      // Stores it accordingly
      max_views = views;
      suggested = i;
    }
  }

  return suggested;
}

// To do - Complete this function
void StreamService::displayContentInfo(CID_T contentID) const
{
  // Do not alter this
  if(!isValidContentID(contentID)){
    throw std::invalid_argument("Watch: invalid contentID");
  }

  // Call the display abitlity of the appropriate content object
  content_[contentID]->display(cout);
}

// Complete - Do not alter
bool StreamService::isValidContentID(CID_T contentID) const
{
  return (contentID >= 0) && (contentID < (int) content_.size());
}

// Complete - Do not alter
void StreamService::throwIfNoCurrentUser() const
{
  if(cUser_ == NULL){
    throw UserNotLoggedInError("No user is logged in");
  }
}

// Complete - Do not alter
int StreamService::getUserIndexByName(const std::string& uname) const
{
  for(size_t i = 0; i < users_.size(); i++){
    if(uname == users_[i]->uname) {
      return (int)i;
    }
  }
  return -1;
}