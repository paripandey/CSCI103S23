// Complete me
#include "customparser.h"
#include <iostream>
#include <sstream>

using namespace std;

const char* error_msg_1 = "Cannot read integer n";
const char* error_msg_2 = "Error in content parsing";
const char* error_msg_3 = "Error in user parsing";

// To Do - Complete this function
void CustomFormatParser::parse(std::istream& is, std::vector<Content*>& content, std::vector<User*>& users)
{
  // Erase any old contents
  content.clear();
  users.clear();

  // TO DO - Add your code below.

  // Store the number of contents
  int contents_size = 0;
  is >> contents_size;

  // In case there's an error in doing so
  if (is.fail()) {
    throw ParserError(error_msg_1);
  }

  // Resize the contents vector
  content.resize(contents_size);
  
  // This will store all the contents
  for (int i = 0; i < contents_size; ++i) {
    // Will store the content attributes
    int id, type, nr, ts, rating, eps;
    // the last 2 variables are just used for temporary storage
    string name, viewers, temp;
    
    is >> id >> type >> ws;
    // The content name shouldn't have any leading or ending whitespace
    getline(is, name, '\n');
    is >> nr >> ts >> rating;

    // If the content is a series, then store the number of episodes
    if (type == 1) {
      is >> eps;
    }

    // If there were any errors in parsing the content
    if (is.fail()) {
      throw ParserError(error_msg_2);
    }

  // Dynamically creates/adds a new movie
      if (type == 0) {
        content[i] = new Movie(id, name, nr, ts, rating);
      }

      // Dynamically creates/adds a new series
      else if (type == 1) {
        content[i] = new Series(id, name, nr, ts, rating, eps);
      }

      // Stores the newline from earlier
      getline(is, viewers);
      // Stores the content's viewers
      getline(is, viewers);
      // In case there are no viewers
      if (!viewers.length()) {
        continue; // Move to the next content
      }

      // Stores the content's viewers
      stringstream ss(viewers);
      // Adds each viewer to the content's viewers
      while (ss >> temp) {
        content[i]->addViewer(temp);
      }
  }

  // This will store all the users
  while (!is.fail()) {
    string temp; // Represents the username for now
    int r_limit, cid; // Rating limit and content ID
    is >> temp >> r_limit;
    // If there are no users -> end of file
    if (!temp.length()) {
      break;
    }

    // Adds the user
    if (!is.fail()) {
      users.push_back(new User(temp, r_limit));
    }

    // If there were any errors in parsing the user
    else {
      throw ParserError(error_msg_3);
    }

    // temp will now store the contents that the user has watched
    getline(is, temp);
    getline(is, temp);
    // If the user has watched nothing
    if (!temp.length()) {
      continue; // Move to the next user
    }

    // Stores all the contents that the user has watched
    stringstream ids(temp);
    // Adds each content to the viewer's watch history
    while (ids >> cid) {
      users[users.size()-1]->addToHistory(cid);
    }  
  }
}