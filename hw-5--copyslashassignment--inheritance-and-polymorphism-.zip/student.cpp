#include <iostream>
#include <string>
#include <vector>
#include <iomanip>
#include "student.h"

using namespace std;


Student::Student(string name){
  name_ = name;
}


void Student::setMajor(string major){
  major_ = major;
}

//Add course to the courses_ vector
//Add course_grade to the grades_ vector
void Student::addCourse(Course* course, double course_grade){
  //You complete
  courses_.push_back(course);
  grades_.push_back(course_grade);
}

//Compute the overall GPA
double Student::getTotalGPA() const {
  //you complete
  double gp = 0;
  int total_credits = 0;

  for (unsigned int i = 0; i < courses_.size(); ++i) {
    if (courses_[i]->getFinalLetterGrade(grades_[i]) == "A") {
      gp += courses_[i]->getNumCredit() * 4;
      total_credits += courses_[i]->getNumCredit();
    }

    else if (courses_[i]->getFinalLetterGrade(grades_[i]) == "B") {
      gp += courses_[i]->getNumCredit() * 3;
      total_credits += courses_[i]->getNumCredit();
    }

    else if (courses_[i]->getFinalLetterGrade(grades_[i]) == "C") {
      gp += courses_[i]->getNumCredit() * 2;
      total_credits += courses_[i]->getNumCredit();
    }

    else if (courses_[i]->getFinalLetterGrade(grades_[i]) == "D") {
      gp += courses_[i]->getNumCredit();
      total_credits += courses_[i]->getNumCredit();
    }

    else if (courses_[i]->getFinalLetterGrade(grades_[i]) == "F") {
      total_credits += courses_[i]->getNumCredit();
    }
  }

  
  return gp/total_credits; //to be changed.
}

//Get the total course credits.
int Student::getSemesterCourseCredit() const {
  //you complete
  int total_credits = 0;

  for (unsigned int i = 0; i < courses_.size(); ++i) {
    if (courses_[i]->getFinalLetterGrade(grades_[i]) != "NP") {
      total_credits += courses_[i]->getNumCredit();
    }
  }

  return total_credits;
}


//***********************
//This function is done. 
//do Not change anything
//***********************
void Student::printReport() const
{
  cout<<"Name: "<<name_<<endl;
  cout<<"Major: "<<major_<<endl;
  cout<<"Courses Taken: "<<endl;
  cout << '|' << setw(10) <<"Course";
  cout << '|' << setw(10) <<"Credit";
  cout << '|' << setw(10) <<"RawGrade";
  cout << '|' << setw(12) <<"LetterGrade";
  cout <<endl;
  cout << '|' << setw(10) <<"----------";
  cout << '|' << setw(10) <<"----------";
  cout << '|' << setw(10) <<"----------";
  cout << '|' << setw(12) <<"------------";
  cout <<endl;
  for(size_t i = 0; i < courses_.size(); i++){
    cout << '|' << setw(10) << courses_[i]->getName();
    cout << '|' << setw(10) << courses_[i]->getNumCredit();
    cout << '|' << setw(10) << grades_[i];
    cout << '|' << setw(12) << courses_[i]->getFinalLetterGrade(grades_[i]);
    cout << endl;
  }
  cout << '|' << setw(10) <<"----------";
  cout << '|' << setw(10) <<"----------";
  cout << '|' << setw(10) <<"----------";
  cout << '|' << setw(12) <<"------------";
  cout <<endl;
  cout<<"Total Credits: "<<getSemesterCourseCredit()<<endl;
  cout<<"Overall GPA: "<< setprecision(2) << std::fixed << getTotalGPA()<<endl;
}
