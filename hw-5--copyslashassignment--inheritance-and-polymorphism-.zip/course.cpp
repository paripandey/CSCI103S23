#include <iostream>
#include <string>
#include <vector>
#include "course.h"

using namespace std;

//You complete the cpp file below
Course::Course(string name, int credit) {
  name_ = name;
  credit_ = credit;
}


