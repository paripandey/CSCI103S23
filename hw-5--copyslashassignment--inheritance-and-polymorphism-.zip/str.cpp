#include <iostream>
#include <stdexcept>
#include <cstring>
#include "str.h"

using namespace std;

// Add your implementations here.
Str::Str() {
  data_ = new char[1];
  *data_ = '\0';
  size_ = 0;
}

Str::Str(const char* s)
{
  if (s == NULL) {
    Str();
  }

  else {
    data_ = new char[strlen(s)+1];
    strcpy(data_, s);
    size_ = strlen(s);
  }
}

Str::Str(const Str& s)
{
  if (s.data_ != NULL) {
    data_ = new char[s.size_+1];
    strcpy(data_, s.data_);
    size_ = s.size_;
  }

  else {
    Str();
  }
}


// Given implementations - DO NOT ALTER
const char* Str::data() const
{
  return data_;
}

char& Str::operator[](unsigned int i)
{
  if(i >= size_ ){
    throw std::out_of_range("Index is out of range");
  }
  return data_[i];
}

char const & Str::operator[](unsigned int i) const
{
  if(i >= size_ ){
    throw std::out_of_range("Index is out of range");
  }
  return data_[i];
}

bool Str::operator<(const Str &rhs) const
{
  return (strcmp(data_, rhs.data_) < 0);
}

bool Str::operator>(const Str &rhs) const
{
  return (strcmp(data_, rhs.data_) > 0);
}

std::istream& operator>>(std::istream& istr, Str& s)
{
  std::string stemp;
  istr >> stemp;
  s = stemp.c_str();
  return istr;
}

std::size_t Str::size() const {
  return size_;
}

Str& Str::operator=(const Str& s) {
  operator=(s.data_);
}

Str& Str::operator=(const char* s)
{
  if (strcmp(data_, s) == 0) { return *this; }
  delete [] data_;
  data_ = new char[strlen(s) + 1];
  strcpy(data_, s);
  size_ = strlen(s);
  return *this;
}

Str& Str::operator+=(const Str& s)
{
  operator+=(s.data_);
}

Str& Str::operator+=(const char* s) {
  if (s == NULL) { return *this; }
  char* temp = new char[size_ + strlen(s) + 1];
  strcpy(temp, data_);
  strcat(temp, s);
  delete [] data_;
  data_ = temp;
  size_ = strlen(data_);
  return *this;
}

Str Str::operator+(const Str& rhs  ) const {
  if (rhs.data_ == NULL) { return *this; }
  Str temp;
  delete [] temp.data_;
  temp.data_ = new char[size_ + strlen(rhs.data_) + 1];
  strcpy(temp.data_, data_);
  strcat(temp.data_, rhs.data_);
  temp.size_ = strlen(temp.data_);
  return temp;
}

Str Str::operator+(const char* rhs  ) const {
  if (rhs == NULL) { return *this; }
  Str temp;
  delete [] temp.data_;
  temp.data_ = new char[size_ + strlen(rhs) + 1];
  strcpy(temp.data_, data_);
  strcat(temp.data_, rhs);
  temp.size_ = strlen(temp.data_);
  return temp;
}

bool Str::operator==(const Str &rhs) const
{
  return !strcmp(data_, rhs.data_);
}

bool Str::operator!=(const Str &rhs) const
{
  return (strcmp(data_, rhs.data_) != 0);
}

std::ostream& operator<<(std::ostream& ostr, Str s)
{
  ostr << s.data_;
  return ostr;
}