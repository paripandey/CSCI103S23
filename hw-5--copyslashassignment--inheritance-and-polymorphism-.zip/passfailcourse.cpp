#include <iostream>
#include <string>
#include <vector>
#include "passfailcourse.h"

using namespace std;

//You complete the cpp file below
PassFailCourse::PassFailCourse(string name, int credit, double threshold)
  : Course(name, credit)
  {
    threshold_ = threshold;
  }

string PassFailCourse::getFinalLetterGrade(double grade)
{
  if (grade >= threshold_) { return "P"; }
  return "NP";
}