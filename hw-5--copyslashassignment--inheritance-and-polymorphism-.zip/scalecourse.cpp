#include <iostream>
#include <string>
#include <vector>
#include "scalecourse.h"

using namespace std;

//You complete the cpp file below
ScaleCourse::ScaleCourse(string name, int credit, vector<double>& scales)
: Course(name, credit)
{
  scales_ = scales;
}

string ScaleCourse::getFinalLetterGrade(double grade) {
  for (unsigned int i = 0; i < scales_.size(); i++) {
    if (grade >= scales_[i]) {
      if (i == 0) { return "A"; }

      else if (i == 1) { return "B"; }

      else if (i == 2) { return "C"; }

      else if (i == 3) { return "D"; }

      else { return "F"; }
    }
  }

  return "F";
}
