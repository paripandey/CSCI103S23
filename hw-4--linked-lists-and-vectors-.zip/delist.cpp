#include "delist.h"
#include <iostream>

using namespace std;

// Add your function implementations here
// Constructs an empty Double-Ended List
DEList::DEList() {
  head = NULL;
  tail = NULL;
  size_ = 0;
}

// Destructor to clean-up memory of current list
DEList::~DEList() {
  DEItem* curr = head;
  while (curr != NULL) {
    DEItem* next = curr->next;
    delete curr;
    curr = next;
  }
}

// returns number of items in the list
int DEList::size() const {
  return size_;
}

// returns a Boolean 'true' if the list is empty
bool DEList::empty() const {
  return (size() == 0);
}

// Adds a new integer to the front of the list
void DEList::push_front(int new_val) {
  DEItem* addend = new DEItem();
  addend->val = new_val;
  addend->prev = NULL;
  
  if (empty()) {
    addend->next = NULL;
    tail = addend;
  }

  else {
    addend->next = head;
    head->prev = addend;
  }

  head = addend;
  size_++;
}

// returns front item or -1 if empty list
int DEList::front() const {
  if (empty()) {
    return -1;
  }

  else {
    return head->val;
  }
}

// Converts the contents of the list to a string with spaces between 
// each element an NO trailing newline (and no space before the 
// first element or after the last element)
std::string DEList::conv_to_string() const {
  string result = "";
  if (!empty()) {
    DEItem* curr = head;
    while (curr != tail) {
      result += std::to_string(curr->val) + " ";
      curr = curr->next;
    }
    
    result += std::to_string(tail->val);
  }

  return result;
}


// Adds a new integer to the back of the list
void DEList::push_back(int new_val) {
  DEItem* addend = new DEItem();
  addend->val = new_val;
  addend->next = NULL;

  if (empty()) {
    addend->prev = NULL;
    head = addend;
  }

  else {
    addend->prev = tail;
    tail->next = addend;
  }
  
  tail = addend;
  size_++;
}


// returns back item or -1 if empty list
int DEList::back() const {
  if (empty()) {
    return -1;
  }

  else {
    return tail->val;
  }
}


// Removes the front item of the list (if it exists)
void DEList::pop_front() {
  if (empty()) {
    return;
  }

  else if (size() == 1) {
    delete head;
    head = NULL;
    tail = NULL;
  }

  else {
    DEItem* after = head->next;
    after->prev = NULL;
    delete head;
    head = after;
  }

  size_--;
}

// Removes the back item of the list (if it exists)
void DEList::pop_back() {
  if (empty()) {
    return;
  }

  else if (size() == 1) {
    delete head;
    head = NULL;
    tail = NULL;
  }

  else {
    DEItem* previous = tail->prev;
    previous->next = NULL;
    delete tail;
    tail = previous;
  }

  size_--;
}
