#include <iostream>
#include "bigint.h"

using namespace std;

// Write your implementation below
BigInt::BigInt(std::string s) {
  for (int i = s.length() - 1; i >= 0; --i) {
    char c = s[i];
    int x = static_cast<int>(c) - '0';
    digits.push_back(x);
  }

}

string BigInt::to_string() const {
  string result = "";
  for (int i = digits.size() - 1; i >= 0; --i) {
    result += static_cast<char>(digits[i] + '0');
  }
  return result;
}

void BigInt::add(BigInt b) {
  int adder = 0, i = 0;
  int c = digits.size();
  int d = b.digits.size();
  
  while (i < c || i < d || adder) {

    if (i == c) {
      digits.push_back(0);
      c = digits.size();
    }

    digits[i] += adder; // from before

    if (i < d) { // b > this
      digits[i] += b.digits[i];
    }

    adder = digits[i]/10;
    digits[i] %= 10;
    i++;
  }
}