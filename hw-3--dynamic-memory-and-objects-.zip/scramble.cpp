// wscramble.cpp
// Word Scramble guessing game
// Illustrates string library functions, character arrays,
//  arrays of pointers, and dynamic allocation, etc.
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <cstring>
#include <fstream>
// TODO 1: Include needed headers for filestreams
using namespace std;

// Scramble the letters of this string randomly
void permute(char items[], int len);

// Seed the random number generator (RNG) with user-provided seed or
//  current time.
// @param [in] seedarg - NULL, if no seed was provided on the command line
//                       or pointer to the C-string containing the seed.
void seedRNG(char* seedarg);

// TODO 2: Delete the integer and array below to no longer be a global, 
// but instead declare them in main() and set the array elements 
// to point at the words read in from the input file 
//const int numWords = 10;
/*const char* wordBank[] = {
   "computer", "president", "trojan", "program", "coffee",
   "library", "football", "popcorn", "science", "engineer"};*/


// TODO 3a: Modify the signature of main to allow for command line args.
int main(int argc, char* argv[]) {
  // TODO 3b: Add argc check as described in the writeup and 
  //          call seedRNG() with appropriate argument
  if (argc < 2) {
    return 1;
  }

  seedRNG(argv[2]);

  // TODO 4-9: Add code to declare the wordBank array and
  //       read in each word from the file specified by argv[1]
  //       and store them appropriately.  If the file cannot
  //       be opened, return 2.

  // TODO 4:
  ifstream ifile(argv[1]);
  if (ifile.fail()) {
    cout << "Error: Cannot open file." << endl;
    return 2;
  }

    // TODO 5:
  int numWords; //
  ifile >> numWords;

  // TODO 6:
  char** wordBank = new char*[numWords];
  
  // TODO 7:
  char buffer[41];

  // TODO 8:
  int i = 0;

  ifile >> buffer;

  while (!ifile.fail() && i < numWords) {
    wordBank[i] = new char[strlen(buffer)+1];
    strcpy(wordBank[i++], buffer);
    ifile >> buffer;
  }

  // TODO 9:
  ifile.close();


  // Complete: More variables for later
  char guess[80] = "";     // blank array for user input
  bool wordGuessed = false;
  int numTurns = 10; 
    
  // Complete: Pick a random word from the wordBank
  int target = rand() % numWords;
  int targetLen = strlen(wordBank[target]);
  cout << "Sol: " << wordBank[target] << endl;
  char* word = NULL;  // pointer to target word

  // TODO 10: Change word to point at a dynamically-allocated copy 
  // of the target word that you create and then 
  // scramble the letters of the array word points to by
  // calling permute() on it

  word = new char[targetLen+1];
  strcpy(word, wordBank[target]);
  permute(word, targetLen);




  // An individual game continues until '!' is entered, a word
  //  is guessed correctly or 10 turns have elapsed
  while (guess[0] != '!' && !wordGuessed && numTurns > 0) {
    cout << "Scrambled word: " << word << endl;
    cout << "What do you guess the original word is? " << endl;
    cin >> guess;
    // TODO 11: Add code to check if the guess is equal to the chosen word.
    // Update wordGuessed to be true if they are equal, and false otherwise.
    if (strcmp(guess, wordBank[target]) == 0) {
      wordGuessed = true;
    }
    numTurns--;   // Every guess counts as a turn
  }
  if(guess[0] == '!'){
    cout << "Quit!" << endl;
  }
  else if(wordGuessed){
    cout << "Win! " << numTurns << " guesses to spare." << endl;
  }
  else {
    cout << "Lose! " << wordBank[target] << endl;
  }

  // TODO 12: Add any necessary cleanup code to avoid memory leaks/errors
  
  
  for (int j = 0; j < numWords; ++j) {
    delete [] wordBank[j];
  }

  delete [] wordBank;

  delete [] word;

  return 0;
}

// Scramble the letters. Uses "Knuth shuffle" algorithm.
void permute(char items[], int len) {
  for (int i = len-1; i > 0; --i) {
    int r = rand() % i;
    char temp = items[i];
    items[i] = items[r];
    items[r] = temp;
  }
}

// Seed the RNG 
void seedRNG(char* seedarg)
{
  if(NULL == seedarg ){
    srand(time(0)); // use the time to get randomly chosen words each run
  }
  else {
    srand(atoi(seedarg)); // use the command line argument as the seed
  }
}
