#include <iostream>
#include <cmath>
#include "quad.h"
using namespace std;

// Global score helper functions for Quad member functions.
// Since we define at the top, and these are only meant to be used
// internally, we will forego the prototype

// Returns true if two doubles are within 0.001 of each other
//  Should be used for all equality and non-equality comparison
//  of doubles
bool same(double a, double b) 
{
    if (fabs(b - a) < 0.001) {
        return true;
    }

    return false;
    // TODO - complete thsi function based on the instructions
    //        above and description in the writeup
}

// Complete - Returns the distance between two points
double dist(Point a, Point b) 
{
    return sqrt( pow(a.px-b.px,2) + pow(a.py-b.py,2));
}


// Quad member function definitions
// ================================
Quad::Quad()
{
    // TODO - Add code to initialize the data member(s) you added
    //        to track which points have been initialized
    //        by user-specified values (and not default values).
    for(int i=0; i < 4; i++){
        pts_[i].px = 0; // give default values;
        pts_[i].py = 0; // give default values;
        init_[i] = false;
        side_[i] = 0;
        angle_[i] = 0;
    }
}
Quad::Quad(Point mypts[])
{
    // TODO - Add code to initialize the data member(s) you added
    //        to track which points have been initialized
    //        by user-specified values (and not default values).
    for(int i=0; i < 4; i++){
        pts_[i] = mypts[i];
        init_[i] = true;
    }

    // OPTIONAL
    side_[0] = dist(pts_[0], pts_[1]);
    side_[1] = dist(pts_[1], pts_[2]);
    side_[2] = dist(pts_[2], pts_[3]);
    side_[3] = dist(pts_[3], pts_[0]);
    angle_[0] = getInteriorAngle(3, 0, 1);
    angle_[1] = getInteriorAngle(0, 1, 2);
    angle_[2] = getInteriorAngle(1, 2, 3);
    angle_[3] = getInteriorAngle(2, 3, 0);

}
// TODO - Define all other necessary member functions

void Quad::setPoint(int idx, Point p) {
    pts_[idx] = p;
    init_[idx] = true;

    side_[0] = dist(pts_[0], pts_[1]);
    side_[1] = dist(pts_[1], pts_[2]);
    side_[2] = dist(pts_[2], pts_[3]);
    side_[3] = dist(pts_[3], pts_[0]);
    angle_[0] = getInteriorAngle(3, 0, 1);
    angle_[1] = getInteriorAngle(0, 1, 2);
    angle_[2] = getInteriorAngle(1, 2, 3);
    angle_[3] = getInteriorAngle(2, 3, 0);
}


bool Quad::isValid() const {
    bool all_init = init_[0] && init_[1] && init_[2] && init_[3];
    bool sum_360 = same(angle_[0] + angle_[1] + angle_[2] + angle_[3], 2 * M_PI);
    
    return all_init && sum_360;
}

// Parallelogram where all sides are equal and angles are 90°
bool Quad::isSquare() const {
    if (isRectangle() && isRhombus()) {
        return true;
    }

    return false;
}

// Parallelogram where all the angles are 90°
bool Quad::isRectangle() const {
    if (isParallelogram()) {
        if (same(angle_[0], M_PI/2) && same(angle_[1], M_PI/2)) {
            return true;
        }
    }
    
    return false;
}

// Parallelogram where all sides are equal
bool Quad::isRhombus() const {
    if (isParallelogram()) {
        if (same(side_[0], side_[1]) && same(side_[1], side_[2]) && same(side_[2], side_[3])) {
            return true;
        }
    }

    return false;
}

bool Quad::isParallelogram() const {
    if (isValid()) {
        if (same(side_[0], side_[2]) && same(side_[1], side_[3])) {
            if (same(angle_[0], angle_[2]) && same(angle_[1], angle_[3])) {
                return true;
            }
        }
    }
    
    return false;
}


double Quad::area() const {
    if (isRectangle()) {
        return side_[0] * side_[1];
    }

    else if (isRhombus()) {
      return 1.0/2 * dist(pts_[0], pts_[2]) * dist(pts_[1], pts_[3]);
    }

  
  return side_[0] * side_[1] * sin(angle_[2]);
}



double Quad::perim() const {
    return side_[0] + side_[1] + side_[2] + side_[3];
}



std::string Quad::conv_to_string() const
{
    string retval;
    if(isValid() == false) {
      return "invalid";
    }
    // TODO - Add code to produce and return the appropriate string
    //        representation of the Quad's points.

    else {
        for (int i = 0; i < 4; ++i) {
            retval += '(' + to_string(pts_[i].px) + ',' + to_string(pts_[i].py) + ')';
            if (i < 3) {
              retval += ' ';
            }
        }

        return retval;
    }
}

double Quad::getInteriorAngle(int ext1, int vert, int ext2 ) const
{
    // TODO - Complete this function - remember the return type
    //        should be in units of radians

    // dist^2
    double angle = acos((pow(dist(pts_[ext1], pts_[vert]), 2) + pow(dist(pts_[vert], pts_[ext2]), 2) - pow(dist(pts_[ext1], pts_[ext2]), 2))/(2*dist(pts_[ext1], pts_[vert])*dist(pts_[vert], pts_[ext2])));
    return angle;



}

