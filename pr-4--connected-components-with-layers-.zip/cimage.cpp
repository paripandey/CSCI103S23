#include "component.h"
#include "cimage.h"
#include "bmplib.h"
#include <deque>
#include <iomanip>
#include <iostream>
#include <cmath>
// You shouldn't need other #include's - Ask permission before adding

using namespace std;

// TO DO: Complete this function
CImage::CImage(const char* bmp_filename)
{
  //  Note: readRGBBMP dynamically allocates a 3D array
  //    (i.e. array of pointers to pointers (1 per row/height) where each
  //    point to an array of pointers (1 per col/width) where each
  //    point to an array of 3 unsigned char (uint8_t) pixels [R,G,B values])

  // ================================================
  // TO DO: call readRGBBMP to initialize img_, h_, and w_;

  // h_ and w_ are passed by reference
  img_ = readRGBBMP(bmp_filename, h_, w_);

  // Leave this check
  if(img_ == NULL) {
    throw std::logic_error("Could not read input file");
  }

  // Set the background RGB color using the upper-left pixel
  for(int i=0; i < 3; i++) {
    bgColor_[i] = img_[0][0][i];
  }

  // ======== This value should work - do not alter it =======
  // RGB "distance" threshold to continue a BFS from neighboring pixels
  bfsBgrdThresh_ = 60;

  // ================================================
  // TO DO: Initialize the vector of vectors of labels to -1

  for (int i = 0; i < h_; ++i) {
    // Declaring the "row" vector with a size
    vector<int> row(w_);
    for (int j = 0; j < w_; ++j) {
      // Array-style access vs. push_back()
      row[j] = -1;
    }
    labels_.push_back(row);
  }

  // ================================================
  // TO DO: Initialize any other data members
}

// TO DO: Complete this function
CImage::~CImage()
{
    // Add code here if necessary
  for (int i = 0; i < h_; ++i) {
    for (int j = 0; j < w_; ++j) {
      // Deletes the RGB array for each pixel
      delete [] img_[i][j];
    }

    // Deletes each row
    delete [] img_[i];
  }

  delete [] img_;
}

// Complete - Do not alter
bool CImage::isCloseToBground(uint8_t p1[3], double within) {
  // Computes "RGB" (3D Cartesian distance)
  double dist = sqrt( pow(p1[0]-bgColor_[0],2) +
                      pow(p1[1]-bgColor_[1],2) +
                      pow(p1[2]-bgColor_[2],2) );
  return dist <= within;
}

// TO DO: Complete this function
size_t CImage::findComponents()
{
    // First component starts at 0
  int label = 0;

  for (int i = 0; i < h_; ++i) {
    for (int j = 0; j < w_; ++j) {
      // Checks if it is a foreground pixel
      bool foreground = !isCloseToBground(img_[i][j], bfsBgrdThresh_);

      // Checks if the pixel is also "empty" (unoccupied by another component)
      if (foreground && labels_[i][j] == -1) {
        // Labels that pixel of the component
        labels_[i][j] = label;
        // Adds the component to the list of components
        components_.push_back(bfsComponent(i, j, label));
        // Increases the label ID for the next component
        label++;
      }
    }
  }

  return numComponents();
}

// Complete - Do not alter
void CImage::printComponents() const
{
  cout << "Height and width of image: " << h_ << "," << w_ << endl;
  cout << setw(4) << "Ord" << setw(4) << "Lbl" << setw(6) << "ULRow" << setw(6) << "ULCol" << setw(4) << "Ht." << setw(4) << "Wi." << endl;
  for(size_t i = 0; i < components_.size(); i++) {
    const Component& c = components_[i];
    cout << setw(4) << i << setw(4) << c.label << setw(6) << c.ulNew.row << setw(6) << c.ulNew.col
    << setw(4) << c.height << setw(4) << c.width << endl;
  }

}


// TODO: Complete this function
int CImage::getComponentIndex(int mylabel) const
{
  for (int i = 0; i < components_.size(); ++i) {
    if (components_[i].label == mylabel) {
      return i;
    }
  }

  // If the component isn't found
  return -1;
}


// Nearly complete - TO DO:
//   Add checks to ensure the new location still keeps
//   the entire component in the legal image boundaries
void CImage::translate(int mylabel, int nr, int nc)
{
  // Get the index of specified component
  int cid = getComponentIndex(mylabel);
  if(cid < 0) {
    return;
  }
  int h = components_[cid].height;
  int w = components_[cid].width;

  // ==========================================================
  // ADD CODE TO CHECK IF THE COMPONENT WILL STILL BE IN BOUNDS
  // IF NOT:  JUST RETURN.

  if (nr < 0 || nc < 0 || nr + h - 1 >= h_ || nc + w - 1 >= w_) {
    return;
  }

  // ==========================================================

  // If we reach here we assume the component will still be in bounds
  // so we update its location.
  Location nl(nr, nc);
  components_[cid].ulNew = nl;
}

// TO DO: Complete this function
void CImage::forward(int mylabel, int delta)
{
  int cid = getComponentIndex(mylabel);
  if(cid < 0 || delta <= 0) {
    return;
  }
  // Add your code here

  // If the delta value is too large
  if (cid + delta >= numComponents()) {
    // "Reset" the delta value to the forwardmost layer
    delta = numComponents() - cid - 1;
  }

  // Stores the component to be shifted
  Component temp = components_[cid];

  int i;

  // Shifts the following element(s) backward
  for (i = cid; i < cid + delta; ++i) {
    components_[i] = components_[i+1];
  }

  // Shifts the component
  components_[i] = temp;
}

// TO DO: Complete this function
void CImage::backward(int mylabel, int delta)
{
  int cid = getComponentIndex(mylabel);
  if(cid < 0 || delta <= 0) {
    return;
  }
  // Add your code here

  // If the delta value is too large
  if (cid - delta < 0) {
    // "Reset" the delta value to the backmost layer
    delta = cid;
  }

  // Stores the component to be shifted
  Component temp = components_[cid];

  int i;

  // Shifts the preceding element(s) forward
  for (i = cid; i > cid - delta; --i) {
    components_[i] = components_[i-1];
  }

  // Shifts the component
  components_[i] = temp;
}

// TODO: complete this function
void CImage::save(const char* filename)
{
  // Create another image filled in with the background color
  uint8_t*** out = newImage(bgColor_);

  // Add your code here

  for (int i = 0; i < numComponents(); ++i) {
    Component cp = components_[i]; // easier access

    for (int r = 0; r < cp.height; r++) {
      int orig_row = cp.ulOrig.row + r;
      int new_row = cp.ulNew.row + r;
      for (int c = 0; c < cp.width; c++) {
        int orig_col = cp.ulOrig.col + c;
        int new_col = cp.ulNew.col + c;

        // If the pixel in the bounding box belongs to the component
        if (labels_[orig_row][orig_col] == cp.label) {
          // Identifies the component (if any) currently at the new location
          int new_label = labels_[new_row][new_col];

          // Identifies both components' indices (order) in the list
          int cid = getComponentIndex(cp.label);
          int ncid = getComponentIndex(new_label);

          // Identifies whether the component at the new location has already been moved itself
          bool has_moved = (components_[ncid].ulOrig.row
          != components_[ncid].ulNew.row || components_[ncid].ulOrig.col
          != components_[ncid].ulNew.col);

          // If the current component is ahead, or the other component has already been moved
          if (cid >= ncid || has_moved) {
            // Updates the output image accordingly
            out[new_row][new_col] = img_[orig_row][orig_col];
          }

          else
          {
            // Updates the output image with the component that's already there
            out[new_row][new_col] = img_[new_row][new_col];
          }
        }
      }
    }
  }

  writeRGBBMP(filename, out, h_, w_);
  // Add any other code you need after this
}

// Complete - Do not alter - Creates a blank image with the background color
uint8_t*** CImage::newImage(uint8_t bground[3]) const
{
  uint8_t*** img = new uint8_t**[h_];
  for(int r=0; r < h_; r++) {
      img[r] = new uint8_t*[w_];
      for(int c = 0; c < w_; c++) {
        img[r][c] = new uint8_t[3];
        img[r][c][0] = bground[0];
        img[r][c][1] = bground[1];
        img[r][c][2] = bground[2];
      }
  }
  return img;
}

// To be completed
void CImage::deallocateImage(uint8_t*** img) const
{
  // Add your code here
  // I just did it in the destructor directly
}

// TODO: Complete the following function or delete this if
//       you do not wish to use it.
Component CImage::bfsComponent(int pr, int pc, int mylabel)
{
  // Arrays to help produce neighbors easily in a loop
  // by encoding the **change** to the current location.
  // Goes in order N, NW, W, SW, S, SE, E, NE

  int neighbor_row[8] = {-1, -1, 0, 1, 1, 1, 0, -1};
  int neighbor_col[8] = {0, -1, -1, -1, 0, 1, 1, 1};

  // Creates the deque
  deque<Location> d;
  // Adds the starting pixel of the component
  d.push_back(Location(pr, pc));

  // Will store the highest, lowest, leftmost, and rightmost pixels
  int um = pr;
  int bm = pr;
  int lm = pc;
  int rm = pc;

  // While the deque isn't empty
  while (!d.empty()) {
    Location curr = d.front(); // Identifies the first element in the deque
    Location neighbor;
    for (int i = 0; i < 8; ++i) {
      neighbor.row = curr.row + neighbor_row[i];
      neighbor.col = curr.col + neighbor_col[i];

      // Checks if the neighbor is valid
      bool valid = neighbor.row < h_ && neighbor.row > -1 && neighbor.col < w_ && neighbor.col > -1;
      
      // Checks if the neighbor is also a foreground pixel
      bool foreground = valid && !isCloseToBground(img_[neighbor.row][neighbor.col], bfsBgrdThresh_);

      // If the foreground pixel is empty/has currently been unlabeled
      if (foreground && labels_[neighbor.row][neighbor.col] == -1) {
        d.push_back(neighbor); // Adds the neighbor to the deque
        labels_[neighbor.row][neighbor.col] = mylabel; // Labels the pixel

        if (neighbor.col < lm) {
          lm = neighbor.col;
        }

        else if (neighbor.col > rm) {
          rm = neighbor.col;
        }

        if (neighbor.row < um) {
          um = neighbor.row;
        }

        else if (neighbor.row > bm) {
          bm = neighbor.row;
        }
      }
    }

    // Removes the first element in the deque
    d.pop_front();
  }

  // Calculates the height and width of the bounding box
  int height = bm - um + 1;
  int width = rm - lm + 1;

  return Component(Location(um, lm), height, width, mylabel);
}

// Complete - Debugging function to save a new image
void CImage::labelToRGB(const char* filename)
{
  //multiple ways to do this -- this is one way
  vector<uint8_t[3]> colors(components_.size());
  for(unsigned int i=0; i<components_.size(); i++) {
    colors[i][0] = rand() % 256;
    colors[i][1] = rand() % 256;
    colors[i][2] = rand() % 256;
  }

  for(int i=0; i<h_; i++) {
    for(int j=0; j<w_; j++) {
      int mylabel = labels_[i][j];
      if(mylabel >= 0) {
        img_[i][j][0] =  colors[mylabel][0];
        img_[i][j][1] =  colors[mylabel][1];
        img_[i][j][2] =  colors[mylabel][2];
      } else {
          img_[i][j][0] = 0;
          img_[i][j][1] = 0;
          img_[i][j][2] = 0;
      }
    }
  }
  writeRGBBMP(filename, img_, h_, w_);
}

// Complete - Do not alter
const Component& CImage::getComponent(size_t i) const
{
  if(i >= components_.size()) {
      throw std::out_of_range("Index to getComponent is out of range");
  }
  return components_[i];
}

// Complete - Do not alter
size_t CImage::numComponents() const
{
  return components_.size();
}

// Complete - Do not alter
void CImage::drawBoundingBoxesAndSave(const char* filename)
{
  for(size_t i=0; i < components_.size(); i++){
    Location ul = components_[i].ulOrig;
    int h = components_[i].height;
    int w = components_[i].width;
    for(int i = ul.row; i < ul.row + h; i++){
      for(int k = 0; k < 3; k++){
        img_[i][ul.col][k] = 255-bgColor_[k];
        img_[i][ul.col+w-1][k] = 255-bgColor_[k];
      }
      // cout << "bb " << i << " " << ul.col << " and " << i << " " << ul.col+w-1 << endl; 
    }
    for(int j = ul.col; j < ul.col + w ; j++){
      for(int k = 0; k < 3; k++){
        img_[ul.row][j][k] = 255-bgColor_[k];
        img_[ul.row+h-1][j][k] = 255-bgColor_[k];
      }
      // cout << "bb2 " << ul.row << " " << j << " and " << ul.row+h-1 << " " << j << endl; 
    }
  }
  writeRGBBMP(filename, img_, h_, w_);
}

// Add other (helper) function definitions here