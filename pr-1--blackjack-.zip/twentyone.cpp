/*******************************************************************************
 * CS 103 Twenty-One (Blackjack) Project
/******************************************************************************/

// Add other #includes if you need
#include <iostream>
#include <cstdlib>

using namespace std;

/* Prototypes */
void shuffle(int cards[]);
void printCard(int id);
int cardValue(int id);
void printHand(int hand[], int numCards);
int getBestScore(int hand[], int numCards);

// Self-created prototype that I defined and explained below the main() function
int hasAce(int hand[], int numCards);


const int NUM_CARDS = 52;

/**
 * Global arrays to be used as look-up tables. You 
 */
const char suit[4] = {'H','S','D','C'};
const char* type[13] = 
  {"2","3","4","5","6","7",
   "8","9","10","J","Q","K","A"};
const int value[13] = {2,3,4,5,6,7,8,9,10,10,10,10,11};

/**
 * Should permute the deck of cards, effectively shuffling it.
 * You must use the Fisher-Yates / Durstenfeld shuffle algorithm
 *  described in the assignment writeup.
 */
void shuffle(int cards[])
{
  for (int i = 51; i >= 1; --i) {
    int j = rand() % (i+1);
    int temp = cards[i];
    cards[i] = cards[j];
    cards[j] = temp;
  }
}

/**
 * Prints the card in a "pretty" format:   "type-suit"
 *  Examples:  K-C  (King of clubs), 2-H (2 of hearts)
 *  Valid Types are: 2,3,4,5,6,7,8,9,10,J,Q,K,A
 *  Valid Suits are: H, D, C, S
 *
 *  Must use the suit and type arrays to lookup
 *   the appropriate characters to print.
 */
void printCard(int id)
{

  /* There is a relationship between the id and the index of suit[] that the id corresponds to.
    More specifically, for any id, integer division of id / 13 == the index of the suit[] array.
    For example, for any id in [0, 12], id / 13 = 0; these ids are 'H' cards, and type[0] == 'H'
    On the other hand, for id 13, 13/ 13 = 1; this card is a 'S' card, and type[1] == 'S'
  */
  
  /* There is a relationship between the id and the index of type[] that the id corresponds to.
    More specifically, for any id, the remainder from id / 13 == the index of the type[] array.
    For example, for id 30 (6-D), 30 % 13 = 4; the type is 6, and type[4] == 6 (stored as a string)
  */

  cout << type[id % 13] << "-" << suit[id / 13];
}

/**
 * Returns the numeric value of the card.
 *  Should return 11 for an ACE and can then
 *  be adjusted externally based on the sum of the score.
 *
 * Must use the values array to lookup the appropriate
 *  card return value.
 */
int cardValue(int id)
{
  /******** You complete ****************/
  // First find out the type of the id
  // Convert to int

  /* type[] and value[] store the same values until index 9 – just of different data types.
    value[] takes care of the types {"J", "Q", "K", "A"}, which correspond to {10, 10, 10, 11} instead
  */

  return value[id % 13];
}

/**
 * Should print out each card in the hand separated by a space and
 * then print a newline at the end.  
 * Should use printCard() to print out each card.
 */
void printHand(int hand[], int numCards)
{
  /******** You complete ****************/

  for (int i = 0; i < numCards; ++i) {
    printCard(hand[i]);
    cout << " ";
  }

  cout << endl;
}

/**
 * Should return the total score of the provided hand.  
 * ACES should be treated as 11s to make the highest possible hand
 *  and only being reduced to 1s as needed to avoid busting.
 */
int getBestScore(int hand[], int numCards)
{
  /******** You complete ****************/

  int sum = 0;

  for (int i = 0; i < numCards; ++i) {
    sum += cardValue(hand[i]);
  }

  return sum;
}

/**
 * Main program logic for the game of 21
 */
int main(int argc, char* argv[])
{
  //---------------------------------------
  // Do not change this code -- Begin
  //---------------------------------------
  if(argc < 2){
    cout << "Error - Please provide the seed value." << endl;
    return 1;
  }
  int seed = atoi(argv[1]);
  srand(seed);

  int cards[52];
  int dhand[9];
  int phand[9];
  //---------------------------------------
  // Do not change this code -- End
  //---------------------------------------

  /******** You complete ****************/
  
  // Declaring all variables
  
  // Tracks whether or not the Player wants to play another hand; it is initialized to 'y' for game 1
  char anotherHand = 'y';

  while (anotherHand == 'y') { // Operates each time that the Player wants to play another hand
    
    bool gameOver = false; // The game is not over when it begins, but it will end at some point

    // Tracks the current index of cards[] to deal next; it should always start at 0 for cards[0]
    int indexTracker = -1;

    // Each player should have 0 cards to begin with; they will start adding more
    int dealerCards = 0;
    int playerCards = 0;

    // Each score should always begin with 0
    int dealerScore = 0;
    int playerScore = 0;

    // The Player always begins the game, which will change at some point
    bool playerTurn = true;

    for (int i = 0; i < 52; ++i) { // Initializes the the deck of cards in order 
      cards[i] = i;
    }

    shuffle(cards); // Shuffles the deck of cards
    
    // Deals the initial 2 cards to each player in an alternating fashion, starting with the Player
    for (int i = 0; i < 2; ++i) {
      phand[i] = cards[++indexTracker]; // indexTracker should start at 0; then, cards[0] becomes the Player's 1st card 
      ++playerCards; // The Player gains a card
      dhand[i] = cards[++indexTracker]; // The next index of cards[] becomes the dealer's 1st card 
      ++dealerCards; // The dealer gains a card
    }
    
    cout << "Dealer: ? ";
    printCard(dhand[1]); // Prints the dealer's hand, concealing the first card (printHand() won't work)
    cout << endl << "Player: ";
    printHand(phand, playerCards); // Print the Player's 2 cards
    
    playerScore = getBestScore(phand, playerCards); // Stores the Player's score
    dealerScore = getBestScore(dhand, dealerCards); // // Stores the dealer's score
    int playerAces11 = hasAce(phand, playerCards); // Stores the Player's number of default Aces (A == 11)


    while (!gameOver) { // While the game is not over
      if ((playerScore < 21) && (playerTurn)) { // If the Player doesn't win or bust, and it's (still) their turn
        char input; // Will store the Player's input if they want to hit or stay
        cout << "Type \'h\' to hit and \'s\' to stay: " << endl;
        cin >> input;
        if (input == 'h') { // If the Player wants to hit

          /* Arrays begin at index 0.
            The Player's number of cards == the index in their hand to be assigned with a card.
            The Player's number of cards increases AFTER the new card is assigned.
          */

          phand[playerCards++] = cards[++indexTracker];

          playerScore = getBestScore(phand, playerCards); // Updates the Player's score
          playerAces11 = hasAce(phand, playerCards);
          

          cout << "Player: ";
          printHand(phand, playerCards); // Prints the Player's updated hand
        }

        else if (input == 's') { // If the Player wants to stand
          playerTurn = false; // It is no longer the player's turn
        }

        else {
          break; // If the Player doesn't enter h or s, the game is over
        }

    }

      else if (playerScore == 21) {
        playerTurn = false; // It is no longer the Player's turn
      }

      // Reduces any Ace(s) to 1 to avoid busting as much as possible
      while (playerAces11 && (playerScore > 21)) {
        playerScore -= 10;
        --playerAces11;
      }

      // If the Player still busts after readjustment

      if (playerScore > 21) {
          cout << "Player busts" << endl;
          cout << "Lose " << playerScore << " " << dealerScore << endl;
          break; // The game is over
        }
      
      /* If it's no longer the Player's turn (they stand), and/or they have reached 21
       If this is not satisfied, the outer while loop (!gameOver) iterates again */

      else if ((!playerTurn) || (playerScore == 21)) {
        
        if (dealerScore == 22) { // If the dealer starts with 2 Aces, 1 must be reduced
          dealerScore = 12;
        }

      /* If the dealer's score is under 17, they must start hitting
      // If this is not satisfied, directly jumps to whether the dealer busts and who wins */


        else if (dealerScore < 17) {
          bool doesBust = false; // The dealer does not bust yet, but this could change

          while ((dealerScore < 17)) { // As long as the dealer's score is under 17

            // The dealer hits, they gain another card, and their score is updated
            dhand[dealerCards++] = cards[++indexTracker];
            dealerScore = getBestScore(dhand, dealerCards);

            // Checks if the dealer (now) has an Ace (that might need to be reduced to 1)
            int ace = hasAce(dhand, dealerCards);
            doesBust = (dealerScore > 21); // Determines whether the dealer currently busts

            while (doesBust) { // If the dealer currently busts, and how to deal with each situation
              
              // The dealer has an Ace, busts if Ace == 11, beats the Player even when Ace == 1, and their score would still be >= 17
              if ((ace) && (dealerScore > 21) && ((dealerScore - 10) > playerScore) && ((dealerScore - 10) >= 17)) {
                dealerScore -= 10; // Reduces Ace to 1 from 11

                if (dealerScore > 21) { // The dealer still busts when Ace == 1 but beats the Player (the main objective)
                  break; // The dealer still busts, and the current while loop is terminated; their score is now above 16
                }
                
                else {
                  doesBust = false; // The dealer no longer busts for now
                }
              }

            // The dealer has an Ace, currently busts, and reducing Ace to 1 would bring their score below or equal to the Player's score
              else if ((ace) && (dealerScore > 21) && ((dealerScore - 10) <= playerScore)) {
                if ((dealerScore - 10) >= 17) { // The dealer's new score with Ace == 1 is now/still above 16 (still might not bust)
                  break;
                }

                else { // Reducing the Ace to 1 from 11 brings the dealer's score to < 17, so they don't bust but must continue hitting
                  dealerScore -= 10;
                  doesBust = false; // The dealer no longer busts

                }
              }

              else if ((!ace) && (dealerScore > 21)) { // The dealer doesn't have an Ace but already busts
                break;
              }

              else { // If none of the above, the dealer does not bust
                doesBust = false;
              }
            }

            /*/ After checking whether the dealer busts...
              The dealer busts, or they don't bust but are already above 17 (but obviously not both)
              If either case is not satisfied, the while loop (dealerScore < 17) iterates again
            */

            if ((doesBust) ^ ((!doesBust) && (dealerScore >= 17))) {
                break; // The while loop (dealerScore < 17) is terminated
            }
          }
        }

        cout << "Dealer: ";
        printHand(dhand, dealerCards); // Prints the dealer's hand (after all necessary hitting)
      
        if (dealerScore > 21) { // Checks if the dealer finally busts
          cout << "Dealer busts " << endl;
          cout << "Win " << playerScore << " " << dealerScore << " " << endl;
          break;
        }

        else if (playerScore > dealerScore) { // Player wins
          cout << "Win ";
        }

        else if (playerScore < dealerScore) { // Dealer wins
          cout << "Lose ";
        }

        else { // Both tie
          cout << "Tie ";
        }

        cout << playerScore << " " << dealerScore << " " << endl; // Prints the final score
        break;
      }

    }

        cout << endl << "Play again? [y/n] " << endl; // Asks the user if they'd to play another hand
        cin >> anotherHand; // If == 'y', the outermost while loop iterates again; otherwise, the game stays over (regardless of gameOver).
    } 
    return 0;
    }

  // Checks how many default Aces that either player has
  int hasAce(int hand[], int numCards) {
    int numAces = 0;
    for (int i = 0; i < numCards; ++i) {
      if (cardValue(hand[i]) == 11) {
        ++numAces;
      }
    }
    return numAces;
  }