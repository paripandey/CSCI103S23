/*
maze.cpp
*/

#include <iostream>
#include "mazeio.h"
#include "queue.h"

using namespace std;

// Prototype for maze_search, which you will fill in below.
int maze_search(char**, int, int);

// Add other prototypes here for any functions you wish to use
int is_valid(char**, int, int);
int find_start_and_end(char**, int, int, Location*, Location*);

// main function to read, solve maze, and print result
int main(int argc, char* argv[]) {
  int rows, cols, result;
  char** mymaze=NULL;
  const char* invalid_char_message = "Error, invalid character.";
  const char* invalid_maze_message = "Invalid maze.";
  const char* no_path_message = "No path could be found!";

  if(argc < 2)
  {
    cout << "Please provide a maze input file" << endl;
    return 1;
  }

  mymaze = read_maze(argv[1], &rows, &cols); // <---TASK: COMPLETE THIS FOR CHECKPOINT 1

  // For checkpoint 2 you should check the validity of the maze
  // You may do so anywhere you please and can abstract that
  // operation with a function or however you like.

  // Using the helper function, checks if the maze is valid

  // Means there are invalid characters in the maze
  if (is_valid(mymaze, rows, cols) == -1) {
    cout << invalid_char_message << endl;
  }

  // Means the maze is invalid
  else if (is_valid(mymaze, rows, cols) == -2) {
    cout << invalid_maze_message << endl;
  }


  // The maze is valid
  else {
    // Called if and only if the maze is valid
    result = maze_search(mymaze, rows, cols);

    // If a path is found (function returns 1)
    if (result) {
      // Prints the dimensions and the maze
      cout << rows << " " << cols << endl;
      print_maze(mymaze, rows, cols);
    }

    // No path is found (returns 0)
    else {
      cout << no_path_message << endl;
    }
  }

    //================================
    // When working on Checkpoint 4, you will need to call maze_search
    // and output the appropriate message or, if successful, print
    // the maze.  But for Checkpoint 1, we print the maze, regardless.
    
    //print_maze(mymaze, rows, cols);

    // Deletes each row of the maze
  for (int i = 0; i < rows; ++i) {
    delete[] mymaze[i];
  }

  // Deletes the maze itself
  delete[] mymaze;

  return 0;
}


// Checks whether the maze is valid
int is_valid(char** maze, int rows, int cols) {
  // Tracks the number of 'S''s in the maze
  int S = 0;
  // Tracks the number of 'F''s in the maze
  int F = 0;

  for (int i = 0; i < rows; ++i) {
    for (int j = 0; j < cols; ++j) {
      // Stores the data in each element
      char element = maze[i][j];

      if (element == 'S') {
        S++;
      }

      else if (element == 'F') {
        F++;
      }

      // If the character is invalid
      else if (element != '.' && element != '#') {
        return -1;
      }

      // If there's more than 1 start or end
      if ((S > 1) ^ (F > 1)) {
        return -2; // The maze is invalid
      }
    }
  }

  // If there is no start and/or no end
  if (!S || !F) {
    return -2;
  }
  
  // The maze is valid
  return 1;
}

int find_start_and_end(char** maze, int rows, int cols, Location* start, Location* end) {
  int S = 0;
  int F = 0;
    
  for (int i = 0; i < rows; ++i) {
    for (int j = 0; j < cols; ++j) {
      if (maze[i][j] == 'S') {
        // Updates the start location's row
        start->row = i;
        // Updates the start location's column
        start->col = j;
        S = 1;
        // If the end location is already found, then quit early
        if (F) {
          return 0;
        }
      }

      // Same procedure for the end location
      else if (maze[i][j] == 'F') {
        end->row = i;
        end->col = j;
        F = 1;
        if (S) {
          return 0;
        }
      }
    }
  }

  return 0;
}

/**************************************************
 * Attempt to find shortest path and return:
 *  1 if successful
 *  0 if no path exists
 *
 * If path is found fill it in with '*' characters
 *  but don't overwrite the 'S' and 'F' cells
 * NOTE: don't forget to deallocate memory in here too!
 *************************************************/

int maze_search(char** maze, int rows, int cols)
{
  // *** You complete **** CHECKPOINT 4

  // *****************************************

  // Stores the start, end, current, and current neighbor locations
  Location start;
  Location end;
  Location loc;
  Location neighbor;

  // Tracks whether the path has been found
  bool found = false;

  // Updates the start and end locations of the maze
  find_start_and_end(maze, rows, cols, &start, &end);

  // Creates the queue
  Queue queue(rows * cols);
  // Adds the start location the queue
  queue.add_to_back(start);

  // Dynamically declares the rows of the explored and predecessor arrays
  int** explored = new int*[rows];
  Location** predecessor = new Location*[rows];

  // Dynamically declares each row's columns of the explored and predecessor arrays
  for (int i = 0; i < rows; ++i) {
    explored[i] = new int[cols];
    predecessor[i] = new Location[cols];
    // By default initializes all locations to unexplored
    for (int j = 0; j < cols; ++j) {
      explored[i][j] = 0;
    }
  }

  // Marks the start location as explored
  explored[start.row][start.col] = 1;

  while (!queue.is_empty()) {

    // While the path hasn't been found
    while (!found) {

      // Retrieves the current first element in the queue
      loc = queue.remove_from_front();

      // Checks the North neighbor          
      neighbor.row = loc.row - 1;
      neighbor.col = loc.col;

      // Conditions: neighbor's row is in the range, empty, and not explored
      if ((neighbor.row > -1) && (maze[neighbor.row][neighbor.col] == '.') && !explored[neighbor.row][neighbor.col]) {
        queue.add_to_back(neighbor); // Adds the neighbor to the queue
        explored[neighbor.row][neighbor.col] = 1; // Marks the neighbor as explored
        predecessor[neighbor.row][neighbor.col] = loc; // Adds its predecessor        
      }

      // If the neighbor is the end location
      else if (neighbor.row == end.row && neighbor.col == end.col) {
        found = true; // Updates found
        break;
      }
      
      // Checks the West neighbor (similar format as above)    
      neighbor.row = loc.row;
      neighbor.col = loc.col - 1;
      
      // Conditions: neighbor's column is in the range, empty, and not explored
      if (neighbor.col > -1 && maze[neighbor.row][neighbor.col] == '.' && !explored[neighbor.row][neighbor.col]) {
        queue.add_to_back(neighbor);
        explored[neighbor.row][neighbor.col] = 1;
        predecessor[neighbor.row][neighbor.col] = loc;
      }

      else if (neighbor.row == end.row && neighbor.col == end.col) {
        found = true;
        break;
      }

      // Checks the South neighbor (similar format as above)
      neighbor.row = loc.row + 1;
      neighbor.col = loc.col;
      
      // Conditions: neighbor's row is in the range, empty, and not explored
      if (neighbor.row < rows && maze[neighbor.row][neighbor.col] == '.' && !explored[neighbor.row][neighbor.col]) {
        queue.add_to_back(neighbor);
        explored[neighbor.row][neighbor.col] = 1;
        predecessor[neighbor.row][neighbor.col] = loc;         
      }

      else if (neighbor.row == end.row && neighbor.col == end.col) {
        found = true;
        break;
      }

      // Checks the East neighbor (similar format as above)
      neighbor.row = loc.row;
      neighbor.col = loc.col + 1;

      // Conditions: neighbor's column is in the range, empty, and not explored
      if (neighbor.col < cols && maze[neighbor.row][neighbor.col] == '.' && !explored[neighbor.row][neighbor.col]) {
        queue.add_to_back(neighbor);
        explored[neighbor.row][neighbor.col] = 1;
        predecessor[neighbor.row][neighbor.col] = loc;         
      }

      else if (neighbor.row == end.row && neighbor.col == end.col) {
        found = true;
        break;
      }
      
      else {
        break;
      }
    }

    if (found) {
      // Starts at the location before the end location
      Location tracker = loc;
      // While the location isn't the start location
      while ((tracker.row != start.row) || (tracker.col != start.col)) {
        // Updates the location with '*'
        maze[tracker.row][tracker.col] = '*';
        // Goes to the preceding location
        tracker = predecessor[tracker.row][tracker.col];
      }
      break; // Quits the outer loop
    }
  }

  // Deletes the rows of the dynamically allocated explored and predecessor arrays
  for (int i = 0; i < rows; ++i) {
    delete[] explored[i];
    delete[] predecessor[i];
  }

  // Dynamically deletes the arrays themselves
  delete[] explored;
  delete[] predecessor;

  // The path was found
  if (found) {
    return 1;
  }

  // No path was found
  return 0;
}