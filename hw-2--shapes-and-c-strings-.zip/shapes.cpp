#include <iostream>
#include <cmath>
#include "bmplib.h"

using namespace std;

// global variable. bad style but ok for this assignment
unsigned char image[SIZE][SIZE];

// Fill in this function:
void draw_rectangle(int top, int left, int height, int width) 
{
  for (int i = 0; i < width; ++i) {
    if (((left+i) >= 0) && ((left + i) < 257)) {
      if ((top >= 0) && (top < 257)) {
        image[top][left + i] = 0;
      }

      if (((top + height - 1) >= 0) && ((top + height - 1) < 257))  {
        image[top + height - 1][left + i] = 0;
      }
    }
  }

  for (int i = 0; i < height; ++i) {
    if (((top + i) >= 0) && ((top + i) < 257)) {
      if ((left >= 0) && (left < 257)) {
        image[top+i][left] = 0;
      }

      if (((left + width - 1) >= 0) && ((left + width - 1) < 257)) {
          image[top + i][left + width - 1] = 0;
      }
    }
  }
}



// Fill in this function:
void draw_ellipse(int cr, int cc, int height, int width) 
{
  double angle = 0;
  while (angle < (2 * M_PI)) {
    int y = static_cast<int>(cr + (height/2.0 * sin(angle)));
    int x = static_cast<int>(cc + (width/2.0 * cos(angle)));
    if ((y >= 0) && (y < 257) && (x >= 0) && (x < 257)) {
      image[y][x] = 0;
    }
    angle += 0.01;
  }
}

// Complete
void print_menu()
{
   cout << "To draw a rectangle, enter: 0 top left height width" << endl;
   cout << "To draw an ellipse, enter: 1 cy cx height width" << endl;
   cout << "To save your drawing as 'output.bmp' and quit, enter: 2" << endl;   
}

int main() 
{
   // initialization
   for (int i = 0; i < SIZE; ++i) {
     for (int j = 0; j < SIZE; ++j) {
       image[i][j] = 255;
     }
   }


   // Main program loop here
   int input = -1;

   while (input != 2) {
     int top_or_cy;
     int left_or_cx;
     int height;
     int width;

     print_menu();
     cin >> input;
    
     if ((input == 0) || (input == 1)) {
      cin >> top_or_cy;
      cin >> left_or_cx;
      cin >> height;
      cin >> width;

      if (input == 0) {
        draw_rectangle(top_or_cy, left_or_cx, height, width);
      }
      else {
        draw_ellipse(top_or_cy, left_or_cx, height, width);
      }
     }

     else {
      break;
     }
   }

   
   
   // Write the resulting image to the .bmp file
   writeGSBMP("output.bmp", image);
   
   return 0;
}
