// game.cpp
// Word guessing game illustrates C-strings, some C-string library functions,
//  functions and array passing.
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <cstring>

using namespace std;

// Prototype. we'll define this below.
int processGuess(char word[], const char targetWord[], char guess);

// Define an array of strings (since a string is just a char array)
//  and since string literals (e.g. "hi") evaluate to the starting address
//  of those characters, we really want an array of char *'s
const char* wordBank[] = {"computer", "president", "trojan", "program",
                          "coffee", "library", "football", "popcorn", 
                          "science", "engineer"};

const int numWords = 10;

int main(int argc, char* argv[])
{
  //------------- Do not modify this code --------------
  if(argc < 2){
    srand(time(0)); // use the time to get randomly chosen words each run
  }
  else {
    srand(atoi(argv[1])); // use the command line argument as the seed
  }

  // Pick a random word from the wordBank
  const char* targetWord = wordBank[rand() % numWords];

  int numTurns = 10; // variable to track how many turns remain

  char word[80];  // a blank array to use to build up the answer
                  // It should be initialized with *'s and then
                  //  change them to the actual letters when the 
                  //  user guesses the letter

  // More initialization code as needed
  for (int i = 0; i < 80; ++i) {
    word[i] = '*';
  }

  bool isEqual = false;
  char guess;
  char lettersGuessed[11];
  char finalWord[strlen(targetWord)+1];

  for (int i = 0; i < strlen(targetWord); ++i) {
    finalWord[i] = word[i];
  }

  finalWord[strlen(targetWord)] = '\0';

  for (int i = 0; i < 10; ++i) {
	  lettersGuessed[i] = '-';
  }

  lettersGuessed[10] = '\0';
    
  while ((numTurns > 0) && (!isEqual)) {
    bool repeated = false;
    int numOccurrences = 0;

    cout << numTurns << " guesses remain: " << finalWord << endl;
    cout << "Enter a letter: " << endl;
    cin >> guess;

    for (int i = 0; i < strlen(lettersGuessed); ++i) {
      if (lettersGuessed[i] == guess) {
        repeated = true;
        break;
      }

      else if (lettersGuessed[i] == '-') {
        lettersGuessed[i] = guess;
        break;
      }
    }

    if (guess == '!') {
      break;
    }

    else {
      if (!repeated) {
        numOccurrences = processGuess(finalWord, targetWord, guess);
        if (strcmp(finalWord, targetWord) == 0) {
          isEqual = true;
          break;
        }

        else {
          if (numOccurrences == 0) {
            numTurns--;
          }
        }
      }

      else {
        numTurns--;
      }
    }
  }
 
  // The game should continue until a word
  //  is guessed correctly, a '!' is entered,
  //  or 10 turns have elapsed without the word being guessed


  // Print out end of game status

  if (guess == '!') {
    cout << "Quit!" << endl;
  }

  else if (!isEqual || numTurns == 0) {
    cout << "Lose! " << finalWord << endl; 
  }

  else if (isEqual) {
    if (numTurns == 1) {
      cout << "Win! " << numTurns << " guess to spare." << endl;
    }

    else if (numTurns > 1) {
      cout << "Win! " << numTurns << " guesses to spare." << endl;
    }
  }

  return 0;
}

// Given the current version of the word, target/selected word, and
// the character that the user just guessed, change the word to 
// "turn on" any occurrences the guess character and return a count
// of how many occurrences of 'guess' were found
int processGuess(char word[], const char targetWord[], char guess)
{
  int numOccurrences = 0;
  for (int i = 0; i < strlen(targetWord); ++i) {
    if (targetWord[i] == guess) {
      word[i] = guess;
      numOccurrences++;
    }
  }
  return numOccurrences;
}